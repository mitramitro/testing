Latest version of the file you may download here:
http://sergey89.ru/files/ffmpeg-php-win32.zip (php_ffmpeg.dll)
http://sergey89.ru/files/ffmpeg-php-win32-all.zip (php_ffmpeg.dll and others DLL's)

Sergey Fedotov <sergey89@gmail.com>